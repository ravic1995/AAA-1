
<?php
$field_firstname = $_POST['cf_name1'];
$field_topic = $_POST['cf_topic'];
$field_message = $_POST['cf_message'];
$file = 'messages.json';
$data = json_decode(file_get_contents($file),1);
$newdata = array('Name'=>$field_firstname, 'Topic' => $field_topic, 'Message'=>$field_message);
$data[] = $newdata;
file_put_contents($file, json_encode($data));
?>
 